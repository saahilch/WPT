export const new_booking=(name,amount)=>{
    return({
        type:"newbooking",
        payload:{
            name,amount
        }
    })
}
export const cancel_booking=(name,amount)=>{
    return({
        type:"cancelbooking",
        payload:{
            name,amount
        }
    })
}
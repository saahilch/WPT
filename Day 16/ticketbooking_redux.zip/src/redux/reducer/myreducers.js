import {combineReducers} from 'redux';
import { managereservation,manageamount,managecancellation } from './reservationreducers';
const bookingStore=combineReducers({
    reservationList:managereservation,
    cancellationList:managecancellation,
    amount:manageamount
})

export default bookingStore;
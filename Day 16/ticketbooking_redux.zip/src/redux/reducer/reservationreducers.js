export const managereservation=(oldreservation=[],action)=>{
    switch(action.type){
        case "newbooking":
            return [...oldreservation,{...action.payload}]
        case "cancelbooking":
            return oldreservation.filter(ob=>ob.name!=action.payload.name)
        default:
            return oldreservation;
    }   

}

export const managecancellation=(oldcancellation=[],action)=>{
    switch(action.type){
        case "cancelbooking":
            return [...oldcancellation,{...action.payload}]
        default:
            return oldcancellation;
    }   

}
export const manageamount=(oldamount=2000,action)=>{
    switch(action.type){
        case "newbooking":
            return oldamount+action.payload.amount
        case "cancelbooking":
            return oldamount-action.payload.amount
        default:
            return oldamount;
    }   

}
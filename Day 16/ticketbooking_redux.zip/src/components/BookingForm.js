import React from 'react'
import { new_booking,cancel_booking } from '../redux/action/bookingaction';
import {useState} from 'react';
import { useDispatch } from 'react-redux';

import {dispatch} from 'react-redux';
const BookingForm=()=>{
    const [formdetails,setformdetails]=useState({name:"",amount:""});
    const dispatch=useDispatch();

    const handleChange=(event)=>{
        let {name,value}=event.target;
        setformdetails({...formdetails,[name]:value})
    }
    const bookticket=()=>{
        const nbook=new_booking(formdetails.name,parseInt(formdetails.amount));
        dispatch(nbook);
    }
    const cancelticket=()=>{
        const cbook=cancel_booking(formdetails.name,parseInt(formdetails.amount));
        dispatch(cbook);
    }
  return (
    <div>
    <h1>Booking   Form</h1>
    <form>
        Name: <input type="text" name="name" id="name"
            value={formdetails.name}
            onChange={handleChange}
        /><br></br>
        Amount: <input type="text" name="amount" id="amount"
            value={formdetails.amount}
            onChange={handleChange}
        /><br></br>
        <button type="button" name="reserve" id="reserve" onClick={bookticket}>Book Ticket</button>
        <button type="button" name="cancel" id="cancel" onClick={cancelticket}>cancel Ticket</button>
    </form>
    </div>
  )
}
export default BookingForm;
import React from 'react'
import { useSelector } from 'react-redux';
const DisplayData=()=>{
    let reservationlist=useSelector((state)=>state.reservationList);
    let cancellationlist=useSelector((state)=>state.cancellationList);
    let amount=useSelector((state)=>state.amount)
  return (
    <div>
       <h2> TicketBooking Details</h2>
       <table border='2'>
        <thead>
            <tr><th>Name</th><th>amount</th></tr>
        </thead>
        <tbody>
            {reservationlist.map(ob=><tr key={ob.name}>
                <td>{ob.name}</td>
                <td>{ob.amount}</td>
            </tr>)}
        </tbody>
       </table>
       <hr></hr>
       <table border='2'>
        <thead>
            <tr><th>Name</th><th>amount</th></tr>
        </thead>
        <tbody>
            {cancellationlist.map(ob=><tr key={ob.name}>
                <td>{ob.name}</td>
                <td>{ob.amount}</td>
            </tr>)}
        </tbody>
       </table>
       <hr></hr>
       <h3>Total amount : {amount}</h3>
    </div>
  )
}
export default DisplayData;


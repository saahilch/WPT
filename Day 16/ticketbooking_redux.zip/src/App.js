import logo from './logo.svg';
import './App.css';
import DisplayData from './components/DisplayData';
import BookingForm from './components/BookingForm';
function App() {
  return (
    <div className="App">
     <h1>Ticket Booking</h1>
     <DisplayData></DisplayData>
     <BookingForm></BookingForm>
    </div>
  );
}

export default App;

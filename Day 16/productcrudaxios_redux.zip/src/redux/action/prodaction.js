export const setproductdetails=(prodarr)=>{
   return({
    type:"setprodarr",
    payload:prodarr
   })
}
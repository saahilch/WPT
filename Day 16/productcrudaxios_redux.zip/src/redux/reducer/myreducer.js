const initialstate={
    proddata:[]
}

export const productReducer=(oldstate=initialstate,action)=>{
    switch(action.type){
        case "setprodarr":
            return {...oldstate,prodarr:[...action.payload]};
        default:
            return oldstate;
    }
}
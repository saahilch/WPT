import {combineReducers} from 'redux'
import {productReducer} from './myreducer';

const reducers=combineReducers({
    allProduct:productReducer
})
export default reducers;
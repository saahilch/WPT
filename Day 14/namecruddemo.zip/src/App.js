import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import NameList from './components/NameList';
import NameForm from './components/NameForm';
import {useState} from 'react';
function App() {
  const [names,setnames]=useState(['Rajan','Revati','Atharva']);
  const addnameinarr=(nm)=>{
    //add nm in to new array and set that array to names
      setnames([...names,nm]);
  }
  const removename=(name)=>{
    //keep all the names other than name
      let newarr=names.filter(nm=>nm!==name);
      //change the names array to newarr
      setnames(newarr)
  }
  const modifyname=(nm,newnm)=>{
      //it will replace matching name by newname 
      //and all other names will remain as it is
     let newarr=names.map(ob=>ob===nm?newnm:ob)
     setnames(newarr);
  }
  return (
    <div>
    {/* display names array in unordered list format */}
      <NameList namearr={names}></NameList>
      <NameForm insertname={addnameinarr} deletename={removename} updatedata={modifyname}></NameForm>
    </div>
  );
}

export default App;

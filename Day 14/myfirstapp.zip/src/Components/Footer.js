import './Footer.css';

const Footer=()=>{
   return(
    <h4> @copy; Copyright reserved</h4>
   )
}
export default Footer;
const Header=(props)=>{
    return(
        <h1>This is header  {props.title}-----{props.value}</h1>
    )
}

export default Header;
import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import CounterClasscomponent from './components/CounterClassComponent';
import CounterFunctionalComponent from './components/CounterFunctionalComponent';
function App() {
  return (
    <div>
      <CounterClasscomponent initialval="10"></CounterClasscomponent>
      <hr></hr>
      <CounterFunctionalComponent></CounterFunctionalComponent>
    </div>
  );
}

export default App;
